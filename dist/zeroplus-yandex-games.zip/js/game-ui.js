"use strict";

(function (G) {
  /* ---- DOM refs ---- */
  var $ = function (id) { return document.getElementById(id); };
  var boardEl = $("board"), statusEl = $("status"),
    resetBtn = $("resetBtn"), newGameBtn = $("newGameBtn"),
    playAsXBtn = $("playAsXBtn"), playAsOBtn = $("playAsOBtn"),
    levelEasyBtn = $("levelEasyBtn"), levelNormalBtn = $("levelNormalBtn"), levelHardBtn = $("levelHardBtn"),
    resultModal = $("resultModal"), modalTitle = $("modalTitle"), modalText = $("modalText"), playAgainBtn = $("playAgainBtn"),
    fireworksConfettiEl = $("fireworksConfetti"), fireworksSparksEl = $("fireworksSparks"),
    celebrationBanner = $("celebrationBanner"), wowLayer = $("wowLayer"),
    difficultySuperWrap = $("difficultySuperWrap"),
    difficultyTrigger = $("difficultyTrigger"), difficultyPopover = $("difficultyPopover"),
    difficultyCurrentLabel = $("difficultyCurrentLabel"),
    boardSizeTrigger = $("boardSizeTrigger"), boardSizePopover = $("boardSizePopover"),
    boardSizeCurrentLabel = $("boardSizeCurrentLabel"), boardSizeOptionsEl = $("boardSizeOptions"),
    hintBtn = $("hintBtn"),
    shopBtn = $("shopBtn"), shopOverlay = $("shopOverlay"), shopItems = $("shopItems"), shopCloseBtn = $("shopCloseBtn"),
    statsWinsEl = $("statsWins"), statsLossesEl = $("statsLosses"), statsDrawsEl = $("statsDraws"),
    leaderboardList = $("leaderboardList"), lbRefreshBtn = $("lbRefreshBtn"),
    adNoticeModal = $("adNoticeModal"), adNoticeText = $("adNoticeText"), adNoticeOkBtn = $("adNoticeOkBtn"),
    userCoinsLabel = $("userCoinsLabel"), coinsValueEl = $("coinsValue"), userCoinsWrap = $("userCoinsWrap");

  var celebrationTimers = [];

  /* ---- board size options ---- */
  for (var sz = 3; sz <= 10; sz++) {
    var opt = document.createElement("button");
    opt.type = "button"; opt.className = "btn board-size-opt";
    opt.dataset.size = String(sz); opt.setAttribute("role", "option");
    opt.setAttribute("aria-selected", "false"); opt.textContent = sz + " \u00d7 " + sz;
    boardSizeOptionsEl.appendChild(opt);
  }

  /* ---- i18n UI update ---- */
  G.applyI18n = function () {
    var t = G.t.bind(G);
    document.title = t("title");
    $("titleText").textContent = t("title");
    playAsXBtn.textContent = t("playAsX"); playAsOBtn.textContent = t("playAsO");
    $("boardSizeTriggerTitle").textContent = t("fieldSize");
    resetBtn.textContent = t("reset");
    newGameBtn.textContent = t("newGame");
    $("diffTriggerTitle").textContent = t("diffTitle");
    levelEasyBtn.textContent = t("easy"); levelNormalBtn.textContent = t("normal"); levelHardBtn.textContent = t("hard");
    playAgainBtn.textContent = t("playAgain");
    celebrationBanner.textContent = t("bannerWin");
    if ($("howToPlay")) $("howToPlay").textContent = t("howToPlay");
    if (hintBtn) hintBtn.textContent = t("hintBtn");
    if (shopBtn) shopBtn.textContent = t("shop");
    if ($("shopCloseBtn")) $("shopCloseBtn").textContent = t("close");
    if ($("lbTitle")) $("lbTitle").textContent = t("leaderboard");
    if (lbRefreshBtn) lbRefreshBtn.textContent = t("lbRefresh");
    if ($("adNoticeTitle")) $("adNoticeTitle").textContent = t("adNoticeTitle");
    if (adNoticeText) adNoticeText.textContent = t("adNoticeBody");
    if (adNoticeOkBtn) adNoticeOkBtn.textContent = t("adNoticeOk");
    if (userCoinsLabel) userCoinsLabel.textContent = t("coins") + ":";
    if (userCoinsWrap) userCoinsWrap.setAttribute("title", t("coins"));
    G.updateDifficultyCurrentLabel();
    G.updateStatsUI();
    G.updateCoinsUI();
    G.updateStatus();
  };

  G.updateCoinsUI = function () {
    if (coinsValueEl) coinsValueEl.textContent = String(Math.max(0, Math.floor(G.coins || 0)));
  };

  G.closeAdNoticeModal = function () { if (adNoticeModal) adNoticeModal.classList.remove("show"); };

  G.openAdNoticeBeforeNewGame = function () {
    G.closeModal();
    if ($("adNoticeTitle")) $("adNoticeTitle").textContent = G.t("adNoticeTitle");
    if (adNoticeText) adNoticeText.textContent = G.t("adNoticeBody");
    if (adNoticeOkBtn) adNoticeOkBtn.textContent = G.t("adNoticeOk");
    if (adNoticeModal) adNoticeModal.classList.add("show");
  };

  G.onNewGameWithAdFlow = function () {
    G.closeShop();
    if (!G.showAds) {
      G.closeModal();
      G.resetGameLocal();
      return;
    }
    G.openAdNoticeBeforeNewGame();
  };

  function afterAdNoticeConfirmed() {
    G.closeAdNoticeModal();
    var reward = G.COINS_PER_NEW_GAME_AD || 10;
    if (G.showNewGameInterstitial) {
      G.showNewGameInterstitial(function (wasShown) {
        if (wasShown) {
          G.coins = Math.max(0, Math.floor(G.coins || 0) + reward);
          G.updateCoinsUI();
          if (G.saveCloud) G.saveCloud();
        }
        G.resetGameLocal();
      });
    } else {
      G.resetGameLocal();
    }
  }

  /* ---- board layout ---- */
  G.applyBoardLayout = function () {
    var n = G.boardSize;
    boardEl.style.setProperty("--bs", String(n));
    boardEl.style.gridTemplateColumns = "repeat(" + n + ", 1fr)";
    boardEl.style.gridTemplateRows = "repeat(" + n + ", 1fr)";
    boardEl.dataset.size = String(n);
    boardEl.setAttribute("aria-label", (G.lang === "en" ? "Board " : "Игровое поле ") + n + (G.lang === "en" ? "x" : " на ") + n);
  };

  G.syncBoardSizeUI = function () {
    boardSizeCurrentLabel.textContent = G.boardSize + " \u00d7 " + G.boardSize;
    boardSizeOptionsEl.querySelectorAll(".board-size-opt").forEach(function (btn) {
      var n = Number(btn.dataset.size), on = n === G.boardSize;
      btn.classList.toggle("active", on); btn.classList.toggle("accent", on);
      btn.setAttribute("aria-selected", String(on));
    });
  };

  /* ---- status ---- */
  G.updateStatus = function () {
    if (G.gameOver) return;
    var t = G.t.bind(G);
    if (G.robotThinking) { statusEl.textContent = t("robotThinks"); return; }
    if (G.currentPlayer === G.robotSymbol) { statusEl.textContent = t("robotTurn") + " (" + G.robotSymbol + ")"; return; }
    statusEl.textContent = G.currentPlayer === "X" ? t("turnX") : t("turnO");
  };

  G.updateSideButtons = function () {
    var playingAsX = G.humanSymbol === "X";
    playAsXBtn.classList.toggle("active", playingAsX); playAsOBtn.classList.toggle("active", !playingAsX);
    playAsXBtn.setAttribute("aria-pressed", String(playingAsX)); playAsOBtn.setAttribute("aria-pressed", String(!playingAsX));
  };

  G.updateLevelButtons = function () {
    var e = G.robotLevel === "easy", n = G.robotLevel === "normal", h = G.robotLevel === "hard";
    levelEasyBtn.classList.toggle("active", e); levelNormalBtn.classList.toggle("active", n); levelHardBtn.classList.toggle("active", h);
    levelEasyBtn.classList.toggle("accent", e); levelNormalBtn.classList.toggle("accent", n); levelHardBtn.classList.toggle("accent", h);
    levelEasyBtn.setAttribute("aria-pressed", String(e)); levelNormalBtn.setAttribute("aria-pressed", String(n)); levelHardBtn.setAttribute("aria-pressed", String(h));
    G.updateDifficultyCurrentLabel();
  };

  G.updateDifficultyCurrentLabel = function () {
    var t = G.t.bind(G);
    var labels = { easy: t("easy"), normal: t("normal"), hard: t("hard") };
    difficultyCurrentLabel.textContent = labels[G.robotLevel] || t("normal");
  };

  G.updateRobotDependentUI = function () {
    difficultySuperWrap.hidden = false;
    if (hintBtn) hintBtn.hidden = false;
  };

  G.refreshPlaySideLock = function () {};

  /* ---- stats UI ---- */
  G.updateStatsUI = function () {
    if (statsWinsEl) statsWinsEl.textContent = G.stats.wins;
    if (statsLossesEl) statsLossesEl.textContent = G.stats.losses;
    if (statsDrawsEl) statsDrawsEl.textContent = G.stats.draws;
  };

  /* ---- leaderboard (боковая панель) ---- */
  G.openLeaderboard = function () {
    if (leaderboardList) leaderboardList.innerHTML = '<p class="lb-loading">' + G.t("lbLoading") + '</p>';
    if (G.loadLeaderboard) G.loadLeaderboard();
  };
  G.closeLeaderboard = function () {};

  G.renderLeaderboard = function (entries) {
    if (!leaderboardList) return;
    leaderboardList.innerHTML = "";
    if (!entries || entries.length === 0) {
      leaderboardList.innerHTML = '<p class="lb-empty">' + G.t("lbEmpty") + '</p>';
      return;
    }
    entries.forEach(function (e) {
      var row = document.createElement("div");
      row.className = "lb-row" + (e.isCurrentPlayer ? " lb-row--you" : "");
      var rank = document.createElement("span"); rank.className = "lb-rank"; rank.textContent = "#" + e.rank;
      var avatar = null;
      if (e.avatar) {
        avatar = document.createElement("img"); avatar.className = "lb-avatar"; avatar.src = e.avatar; avatar.alt = "";
      }
      var name = document.createElement("span"); name.className = "lb-name";
      name.textContent = e.name + (e.isCurrentPlayer ? " " + G.t("lbYou") : "");
      var score = document.createElement("span"); score.className = "lb-score"; score.textContent = e.score;
      row.appendChild(rank);
      if (avatar) row.appendChild(avatar);
      row.appendChild(name);
      row.appendChild(score);
      leaderboardList.appendChild(row);
    });
  };

  G.showLeaderboardError = function () {
    if (leaderboardList) leaderboardList.innerHTML = '<p class="lb-empty">' + G.t("lbError") + '</p>';
  };

  /* ---- board ---- */
  G.createBoard = function () {
    boardEl.innerHTML = "";
    var n = G.boardSize, line = "1.5px solid var(--grid-line-color)";
    for (var i = 0; i < n * n; i++) {
      var row = Math.floor(i / n), col = i % n;
      var cell = document.createElement("button");
      cell.type = "button"; cell.className = "cell"; cell.dataset.index = String(i);
      cell.setAttribute("aria-label", (G.lang === "en" ? "Cell " : "Клетка ") + (row + 1) + ", " + (col + 1));
      cell.style.borderTop = "none"; cell.style.borderLeft = "none";
      cell.style.borderRight = col < n - 1 ? line : "none";
      cell.style.borderBottom = row < n - 1 ? line : "none";
      boardEl.appendChild(cell);
    }
    G.applyBoardLayout();
  };

  G.disableBoard = function () {
    boardEl.querySelectorAll(".cell").forEach(function (c) { c.classList.add("disabled"); c.disabled = true; });
  };
  G.enableBoard = function () {
    boardEl.querySelectorAll(".cell").forEach(function (c) { c.classList.remove("disabled"); c.disabled = false; });
  };

  /* ---- mark cell ---- */
  G.markCell = function (cell, player, options) {
    var silent = options && options.silent;
    var mark = document.createElement("span");
    mark.className = "mark mark-" + player.toLowerCase();
    mark.style.setProperty("--rot", player === "X" ? "-6deg" : "5deg");
    if (silent) { mark.style.opacity = "1"; mark.style.animation = "none"; mark.style.transform = "scale(1) rotate(" + (player === "X" ? "-6deg" : "5deg") + ")"; }

    var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 100 100"); svg.setAttribute("class", "mark-svg");
    svg.setAttribute("aria-hidden", "true"); svg.setAttribute("focusable", "false");

    var scheduleDraw = function (path, delaySec, durationSec) {
      requestAnimationFrame(function () {
        var len = path.getTotalLength();
        path.style.setProperty("--path-len", String(len));
        path.style.strokeDasharray = String(len);
        if (silent) { path.style.strokeDashoffset = "0"; path.style.animation = "none"; }
        else { path.style.strokeDashoffset = String(len); path.style.animation = "drawPencilStroke " + durationSec + "s cubic-bezier(0.33,0.85,0.45,1) " + delaySec + "s forwards"; }
      });
    };

    if (player === "X") {
      [{ d: "M 22 24 Q 50 48 76 76", delay: 0, dur: 0.38, extra: "x-thick" },
       { d: "M 76 24 Q 50 52 22 76", delay: 0.14, dur: 0.38, extra: "x-thick" }]
        .forEach(function (s) {
          var p = document.createElementNS("http://www.w3.org/2000/svg", "path");
          p.setAttribute("d", s.d); p.setAttribute("class", "pencil-stroke " + s.extra);
          svg.appendChild(p); scheduleDraw(p, s.delay, s.dur);
        });
    } else {
      var p = document.createElementNS("http://www.w3.org/2000/svg", "path");
      p.setAttribute("d", "M 50 17 C 31 17 17 31 17 50 C 17 69 31 83 50 83 C 69 83 83 69 83 50 C 83 31 69 17 50 17 Z");
      p.setAttribute("class", "pencil-stroke"); svg.appendChild(p); scheduleDraw(p, 0, 0.52);
    }
    mark.appendChild(svg); cell.appendChild(mark); cell.classList.add("filled");
    if (!silent) spawnWowNearCell(cell);
  };

  function spawnWowNearCell(cell) {
    var labels = G.t("wow");
    var rect = cell.getBoundingClientRect();
    var pop = document.createElement("span");
    pop.className = "wow-pop wow-pop--cell";
    pop.textContent = labels[Math.floor(Math.random() * labels.length)];
    var corners = [[0.82,0.2],[0.82,0.8],[0.18,0.22],[0.18,0.78]];
    var c = corners[Math.floor(Math.random() * corners.length)];
    pop.style.left = (rect.left + rect.width * c[0]) + "px";
    pop.style.top = (rect.top + rect.height * c[1]) + "px";
    pop.style.setProperty("--r", (-6 + Math.random() * 12) + "deg");
    wowLayer.appendChild(pop);
    setTimeout(function () { pop.remove(); }, 840);
  }

  /* ---- modals ---- */
  G.showModal = function (title, text) { modalTitle.textContent = title; modalText.textContent = text; resultModal.classList.add("show"); };
  G.closeModal = function () { resultModal.classList.remove("show"); };

  /* ---- celebrations ---- */
  G.clearCelebration = function () {
    celebrationTimers.forEach(clearTimeout); celebrationTimers = [];
    if (fireworksSparksEl) fireworksSparksEl.innerHTML = "";
    if (fireworksConfettiEl) fireworksConfettiEl.innerHTML = "";
    celebrationBanner.hidden = true; wowLayer.innerHTML = "";
    document.body.classList.remove("celebrating");
  };

  function createConfetti(amount) {
    var palette = ["#ff4d6d","#ffbe0b","#3a86ff","#2ec4b6","#8338ec","#fb5607","#80ed99"];
    var frag = document.createDocumentFragment();
    for (var i = 0; i < amount; i++) {
      var piece = document.createElement("span"); piece.className = "confetti";
      piece.style.left = (Math.random() * 100) + "%";
      piece.style.background = palette[Math.floor(Math.random() * palette.length)];
      piece.style.setProperty("--drift", (-72 + Math.random() * 144) + "px");
      piece.style.setProperty("--fall", (3600 + Math.random() * 2400) + "ms");
      piece.style.setProperty("--r", (Math.random() * 360) + "deg");
      piece.style.animationDelay = (Math.random() * 480) + "ms";
      frag.appendChild(piece);
    }
    fireworksConfettiEl.appendChild(frag);
  }

  function launchFireworks(fullReset, confettiAmount) {
    if (fullReset) { fireworksSparksEl.innerHTML = ""; fireworksConfettiEl.innerHTML = ""; }
    else fireworksSparksEl.innerHTML = "";
    var bursts = fullReset ? 8 : 5, sparksPerBurst = fullReset ? 24 : 20;
    var colors = ["#ffd166","#ef476f","#06d6a0","#118ab2","#f28482","#7c83fd","#ffc857","#8ac926","#ff6b9d","#00f5d4"];
    var frag = document.createDocumentFragment();
    for (var b = 0; b < bursts; b++) {
      var cx = 6 + Math.random() * 88, cy = 8 + Math.random() * 58;
      for (var i = 0; i < sparksPerBurst; i++) {
        var spark = document.createElement("span"); spark.className = "spark";
        var angle = (Math.PI * 2 * i) / sparksPerBurst + (Math.random() - 0.5) * 0.35;
        var dist = 52 + Math.random() * 118;
        spark.style.left = cx + "%"; spark.style.top = cy + "%";
        spark.style.setProperty("--dx", (Math.cos(angle) * dist) + "px");
        spark.style.setProperty("--dy", (Math.sin(angle) * dist) + "px");
        spark.style.background = colors[Math.floor(Math.random() * colors.length)];
        spark.style.animationDelay = (b * 85 + Math.random() * 90) + "ms";
        frag.appendChild(spark);
      }
    }
    fireworksSparksEl.appendChild(frag);
    createConfetti(confettiAmount);
  }

  function spawnCenterWow(text) {
    var pop = document.createElement("span"); pop.className = "wow-pop wow-pop--center"; pop.textContent = text;
    pop.style.left = "50%"; pop.style.top = "48%";
    pop.style.setProperty("--r", (-8 + Math.random() * 16) + "deg");
    wowLayer.appendChild(pop); setTimeout(function () { pop.remove(); }, 1320);
  }

  G.launchCelebration = function () {
    G.clearCelebration(); document.body.classList.add("celebrating");
    celebrationBanner.hidden = false;
    var celebTexts = G.t("celeb");
    requestAnimationFrame(function () { launchFireworks(true, 88); });
    spawnCenterWow(celebTexts[0]);
    celebrationTimers.push(setTimeout(function () { requestAnimationFrame(function () { launchFireworks(false, 36); }); }, 520));
    celebrationTimers.push(setTimeout(function () { requestAnimationFrame(function () { launchFireworks(false, 36); }); }, 1050));
    celebrationTimers.push(setTimeout(function () { spawnCenterWow(celebTexts[1]); }, 1100));
    celebrationTimers.push(setTimeout(function () { requestAnimationFrame(function () { launchFireworks(false, 34); }); }, 1680));
    celebrationTimers.push(setTimeout(function () { spawnCenterWow(celebTexts[2]); }, 1750));
    celebrationTimers.push(setTimeout(function () { requestAnimationFrame(function () { launchFireworks(false, 32); }); }, 2350));
    celebrationTimers.push(setTimeout(function () { spawnCenterWow(celebTexts[3] || celebTexts[0]); }, 2400));
    celebrationTimers.push(setTimeout(function () { fireworksSparksEl.innerHTML = ""; fireworksConfettiEl.innerHTML = ""; }, 10200));
    celebrationTimers.push(setTimeout(function () { celebrationBanner.hidden = true; }, 10400));
    celebrationTimers.push(setTimeout(function () { document.body.classList.remove("celebrating"); }, 10800));
  };

  /* ---- game flow ---- */
  G.showEndGameUI = function (winner) {
    G.gameOver = true; G.disableBoard(); boardEl.classList.add("finished"); G.robotThinking = false;
    var t = G.t.bind(G);
    var isHumanWin = winner != null && winner === G.humanSymbol;
    if (winner === "X") {
      statusEl.textContent = t("winX");
      if (isHumanWin) { G.launchCelebration(); G.stats.wins++; } else G.stats.losses++;
      G.showModal(t("winX"), isHumanWin ? t("winMsg") : t("loseMsg"));
    } else if (winner === "O") {
      statusEl.textContent = t("winO");
      if (isHumanWin) { G.launchCelebration(); G.stats.wins++; } else G.stats.losses++;
      G.showModal(t("winO"), isHumanWin ? t("winMsg") : t("loseMsg"));
    } else {
      statusEl.textContent = t("draw"); G.stats.draws++;
      G.showModal(t("draw"), t("drawMsg"));
    }
    G.updateStatsUI();
    if (G.submitScore) G.submitScore();
    if (G.saveCloud) G.saveCloud();
  };

  G.applyMove = function (index) {
    if (index < 0 || index >= G.board.length || G.board[index] !== null || G.gameOver) return false;
    var cell = boardEl.querySelector('.cell[data-index="' + index + '"]');
    if (!cell) return false;
    G.board[index] = G.currentPlayer;
    G.markCell(cell, G.currentPlayer);
    var winner = G.checkWinner();
    if (winner) { G.showEndGameUI(winner); return true; }
    if (G.isDraw()) { G.showEndGameUI(null); return true; }
    G.currentPlayer = G.currentPlayer === "X" ? "O" : "X";
    G.updateStatus(); return true;
  };

  G.scheduleRobotMove = function () {
    if (!G.robotEnabled || G.gameOver || G.currentPlayer !== G.robotSymbol) return;
    G.robotThinking = true; G.updateStatus();
    setTimeout(function () {
      if (G.gameOver || !G.robotEnabled || G.currentPlayer !== G.robotSymbol) { G.robotThinking = false; G.updateStatus(); return; }
      var move = G.pickRobotMove();
      G.robotThinking = false; G.applyMove(move);
    }, 350);
  };

  G.resetGameLocal = function () {
    G.board = Array(G.boardSize * G.boardSize).fill(null);
    G.currentPlayer = G.robotEnabled && G.humanSymbol === "O" ? G.robotSymbol : "X";
    G.gameOver = false; G.robotThinking = false;
    G.closeModal(); boardEl.classList.remove("finished"); G.clearCelebration();
    G.createBoard(); G.enableBoard(); G.updateStatus(); G.scheduleRobotMove();
  };

  G.resetGame = function () {
    G.resetGameLocal();
  };

  /* ---- hint (rewarded ad) ---- */
  function doHint() {
    if (G.gameOver || !G.robotEnabled || G.currentPlayer === G.robotSymbol || G.robotThinking) return;
    var move = G.getHintMove();
    if (move == null) return;
    var cell = boardEl.querySelector('.cell[data-index="' + move + '"]');
    if (cell) { cell.style.boxShadow = "inset 0 0 0 3px rgba(255,200,0,0.7)"; setTimeout(function () { cell.style.boxShadow = ""; }, 2000); }
  }

  /* ---- skin theme ---- */
  G.applySkin = function (skinId) {
    document.body.classList.remove("theme-neon", "theme-wood", "theme-space");
    if (skinId) document.body.classList.add("theme-" + skinId.replace("skin_", ""));
    G.activeSkin = skinId;
  };

  /* ---- popovers ---- */
  function positionPopover(trigger, popover) {
    var r = trigger.getBoundingClientRect(), pad = 8, vw = window.innerWidth;
    var width = Math.min(Math.max(r.width, 200), vw - pad * 2);
    var left = r.left + (r.width - width) / 2;
    left = Math.max(pad, Math.min(left, vw - pad - width));
    popover.style.left = left + "px"; popover.style.width = width + "px";
    var top = r.bottom + 6; popover.style.top = top + "px";
    var pr = popover.getBoundingClientRect();
    if (pr.bottom > window.innerHeight - pad) { top = Math.max(pad, r.top - pr.height - 6); popover.style.top = top + "px"; }
  }

  function closePopover(popover, trigger) { if (popover.hidden) return; popover.hidden = true; trigger.setAttribute("aria-expanded", "false"); }
  function openPopover(popover, trigger, otherPopover, otherTrigger) {
    closePopover(otherPopover, otherTrigger); popover.hidden = false; trigger.setAttribute("aria-expanded", "true");
    requestAnimationFrame(function () { positionPopover(trigger, popover); positionPopover(trigger, popover); });
  }

  var closeDiff = function () { closePopover(difficultyPopover, difficultyTrigger); };
  var closeBoardSize = function () { closePopover(boardSizePopover, boardSizeTrigger); };
  var openDiff = function () { openPopover(difficultyPopover, difficultyTrigger, boardSizePopover, boardSizeTrigger); };
  var openBoardSize = function () { openPopover(boardSizePopover, boardSizeTrigger, difficultyPopover, difficultyTrigger); };

  /* ---- shop ---- */
  G.openShop = function () { if (shopOverlay) shopOverlay.classList.add("show"); };
  G.closeShop = function () { if (shopOverlay) shopOverlay.classList.remove("show"); };
  G.renderShopItems = function (catalog) {
    if (!shopItems) return;
    shopItems.innerHTML = "";
    var t = G.t.bind(G);
    var descs = {
      disable_ads: { name: t("disableAds"), desc: t("disableAdsDesc") },
      skin_neon: { name: t("skinNeon"), desc: t("skinNeonDesc") },
      skin_wood: { name: t("skinWood"), desc: t("skinWoodDesc") },
      skin_space: { name: t("skinSpace"), desc: t("skinSpaceDesc") }
    };
    catalog.forEach(function (product) {
      var d = descs[product.id] || { name: product.title, desc: product.description };
      var owned = (product.id === "disable_ads" && !G.showAds) || G.ownedSkins.indexOf(product.id) !== -1;
      var div = document.createElement("div");
      div.className = "shop-item" + (owned ? " owned" : "");
      var infoDiv = document.createElement("div"); infoDiv.className = "shop-item-info";
      var nameEl = document.createElement("div"); nameEl.className = "shop-item-name"; nameEl.textContent = d.name;
      var descEl = document.createElement("div"); descEl.className = "shop-item-desc"; descEl.textContent = owned ? t("owned") : d.desc;
      infoDiv.appendChild(nameEl); infoDiv.appendChild(descEl); div.appendChild(infoDiv);
      if (!owned) {
        var priceDiv = document.createElement("div"); priceDiv.className = "shop-item-price";
        if (product.getPriceCurrencyImage) {
          var img = document.createElement("img"); img.src = product.getPriceCurrencyImage("small"); img.alt = "";
          priceDiv.appendChild(img);
        }
        var priceSpan = document.createElement("span"); priceSpan.textContent = product.priceValue || product.price || "?";
        priceDiv.appendChild(priceSpan); div.appendChild(priceDiv);
        var btn = document.createElement("button"); btn.type = "button"; btn.className = "btn btn-tiny";
        btn.textContent = t("buy"); btn.dataset.productId = product.id;
        btn.addEventListener("click", function () { if (G.doPurchase) G.doPurchase(product.id); });
        div.appendChild(btn);
      }
      shopItems.appendChild(div);
    });
  };

  /* ---- event bindings ---- */
  boardEl.addEventListener("click", function (event) {
    var target = event.target.closest(".cell");
    if (!target || G.gameOver || G.robotThinking) return;
    if (G.currentPlayer === G.robotSymbol) return;
    var idx = Number(target.dataset.index);
    if (G.board[idx] !== null) return;
    G.applyMove(idx); G.scheduleRobotMove();
  });

  resetBtn.addEventListener("click", function () { G.resetGame(); });
  newGameBtn.addEventListener("click", function () { G.onNewGameWithAdFlow(); });

  function setHumanSymbol(sym) {
    G.humanSymbol = sym; G.robotSymbol = sym === "X" ? "O" : "X";
    G.updateSideButtons(); G.resetGame();
  }
  playAsXBtn.addEventListener("click", function () { setHumanSymbol("X"); });
  playAsOBtn.addEventListener("click", function () { setHumanSymbol("O"); });

  function setRobotLevel(level) { G.robotLevel = level; G.updateLevelButtons(); if (G.robotEnabled) G.resetGame(); }
  difficultyTrigger.addEventListener("click", function (e) { e.stopPropagation(); if (difficultyPopover.hidden) openDiff(); else closeDiff(); });
  boardSizeTrigger.addEventListener("click", function (e) { e.stopPropagation(); if (boardSizePopover.hidden) openBoardSize(); else closeBoardSize(); });

  document.addEventListener("click", function (e) {
    if (!difficultyPopover.hidden && !difficultyTrigger.contains(e.target) && !difficultyPopover.contains(e.target)) closeDiff();
    if (!boardSizePopover.hidden && !boardSizeTrigger.contains(e.target) && !boardSizePopover.contains(e.target)) closeBoardSize();
  });
  window.addEventListener("resize", function () { closeDiff(); closeBoardSize(); });
  window.addEventListener("scroll", function () { closeDiff(); closeBoardSize(); }, true);

  levelEasyBtn.addEventListener("click", function () { setRobotLevel("easy"); closeDiff(); });
  levelNormalBtn.addEventListener("click", function () { setRobotLevel("normal"); closeDiff(); });
  levelHardBtn.addEventListener("click", function () { setRobotLevel("hard"); closeDiff(); });

  playAgainBtn.addEventListener("click", function () { G.onNewGameWithAdFlow(); });
  resultModal.addEventListener("click", function (e) { if (e.target === resultModal) G.closeModal(); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeDiff(); closeBoardSize(); G.closeModal(); G.closeShop(); G.closeAdNoticeModal();
    }
  });

  if (adNoticeOkBtn) adNoticeOkBtn.addEventListener("click", function () { afterAdNoticeConfirmed(); });
  if (adNoticeModal) adNoticeModal.addEventListener("click", function (e) { if (e.target === adNoticeModal) G.closeAdNoticeModal(); });

  if (lbRefreshBtn) lbRefreshBtn.addEventListener("click", function () { G.openLeaderboard(); });

  boardSizeOptionsEl.addEventListener("click", function (e) {
    var o = e.target.closest(".board-size-opt");
    if (!o || G.isOnline()) return;
    G.boardSize = G.clampBoardSize(Number(o.dataset.size));
    G.winLen = G.boardSize; G.rebuildWinningLines(); G.resetGameLocal(); G.syncBoardSizeUI(); closeBoardSize();
  });

  if (hintBtn) hintBtn.addEventListener("click", function () {
    if (G.showAds && G.showRewardedAd) G.showRewardedAd(doHint);
    else doHint();
  });
  if (shopBtn) shopBtn.addEventListener("click", function () { G.openShop(); });
  if (shopCloseBtn) shopCloseBtn.addEventListener("click", function () { G.closeShop(); });
  if (shopOverlay) shopOverlay.addEventListener("click", function (e) { if (e.target === shopOverlay) G.closeShop(); });

  /* ---- contextmenu / longtap prevention (Yandex Games 1.6.1.8 & 1.6.2.7) ---- */
  document.addEventListener("contextmenu", function (e) { e.preventDefault(); });

  /* ---- init ---- */
  G.initUI = function () {
    G.updateSideButtons(); G.updateLevelButtons(); G.syncBoardSizeUI();
    G.updateRobotDependentUI(); G.updateStatsUI(); G.updateCoinsUI();
    G.resetGame();
  };
})(window.Game);
