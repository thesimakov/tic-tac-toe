"use strict";

(function (G) {
  var AD_COOLDOWN = 60000;
  var catalogCache = null;

  function detectLang(ysdk) {
    try {
      var sdkLang = ysdk.environment.i18n.lang;
      if (sdkLang && G.texts[sdkLang]) return sdkLang;
      if (sdkLang && sdkLang.startsWith("ru")) return "ru";
      if (sdkLang && sdkLang.startsWith("en")) return "en";
    } catch (e) {}
    return "ru";
  }

  function initPayments(ysdk) {
    ysdk.getPayments().then(function (payments) {
      G.payments = payments;
      checkPendingPurchases(payments);
      loadCatalog(payments);
    }).catch(function () {});
  }

  function checkPendingPurchases(payments) {
    payments.getPurchases().then(function (purchases) {
      purchases.forEach(function (p) {
        if (p.productID === "disable_ads") {
          G.showAds = false;
        } else if (p.productID.startsWith("skin_")) {
          if (G.ownedSkins.indexOf(p.productID) === -1) G.ownedSkins.push(p.productID);
          payments.consumePurchase(p.purchaseToken);
        }
      });
    }).catch(function () {});
  }

  function loadCatalog(payments) {
    payments.getCatalog().then(function (products) {
      catalogCache = products;
      G.renderShopItems(products);
    }).catch(function () {});
  }

  G.doPurchase = function (productId) {
    if (!G.payments) return;
    G.payments.purchase({ id: productId }).then(function (purchase) {
      if (productId === "disable_ads") {
        G.showAds = false;
      } else if (productId.startsWith("skin_")) {
        if (G.ownedSkins.indexOf(productId) === -1) G.ownedSkins.push(productId);
        G.applySkin(productId);
        G.payments.consumePurchase(purchase.purchaseToken);
      }
      if (catalogCache) G.renderShopItems(catalogCache);
      if (G.saveCloud) G.saveCloud();
    }).catch(function () {});
  };

  G.showInterstitialAd = function (afterCallback) {
    if (!G.showAds || !G.ysdk) { if (afterCallback) afterCallback(); return; }
    var now = Date.now();
    if (now - G.lastAdTime < AD_COOLDOWN) { if (afterCallback) afterCallback(); return; }
    G.ysdk.adv.showFullscreenAdv({
      callbacks: {
        onOpen: function () {
          try { G.ysdk.features.GameplayAPI.stop(); } catch (e) {}
        },
        onClose: function (wasShown) {
          G.lastAdTime = Date.now();
          try { G.ysdk.features.GameplayAPI.start(); } catch (e) {}
          if (afterCallback) afterCallback();
        },
        onError: function () {
          try { G.ysdk.features.GameplayAPI.start(); } catch (e) {}
          if (afterCallback) afterCallback();
        }
      }
    });
  };

  /** Полноэкранная реклама при «Новая игра» — каждый раз, без кулдауна. afterCallback(wasShown). */
  G.showNewGameInterstitial = function (afterCallback) {
    if (!G.showAds || !G.ysdk) {
      if (afterCallback) afterCallback(false);
      return;
    }
    G.ysdk.adv.showFullscreenAdv({
      callbacks: {
        onOpen: function () {
          try { G.ysdk.features.GameplayAPI.stop(); } catch (e) {}
        },
        onClose: function (wasShown) {
          G.lastAdTime = Date.now();
          try { G.ysdk.features.GameplayAPI.start(); } catch (e) {}
          if (afterCallback) afterCallback(Boolean(wasShown));
        },
        onError: function () {
          try { G.ysdk.features.GameplayAPI.start(); } catch (e) {}
          if (afterCallback) afterCallback(false);
        }
      }
    });
  };

  G.showRewardedAd = function (rewardCallback) {
    if (!G.ysdk) { if (rewardCallback) rewardCallback(); return; }
    G.ysdk.adv.showRewardedVideo({
      callbacks: {
        onOpen: function () {
          try { G.ysdk.features.GameplayAPI.stop(); } catch (e) {}
        },
        onRewarded: function () {
          if (rewardCallback) rewardCallback();
        },
        onClose: function () {
          try { G.ysdk.features.GameplayAPI.start(); } catch (e) {}
        },
        onError: function () {
          try { G.ysdk.features.GameplayAPI.start(); } catch (e) {}
        }
      }
    });
  };

  /* ---- auth ---- */
  function initAuth(ysdk) {
    var loginBtn = document.getElementById("loginBtn");
    var userBar = document.getElementById("userBar");
    var userAvatar = document.getElementById("userAvatar");
    var userName = document.getElementById("userName");

    ysdk.getPlayer({ scopes: false }).then(function (player) {
      G.player = player;
      var mode = player.getMode();
      if (mode === "lite") {
        if (loginBtn) loginBtn.hidden = false;
      } else {
        showPlayerInfo(player);
      }
      loadCloudData(player);
    }).catch(function () {});

    function showPlayerInfo(player) {
      if (loginBtn) loginBtn.hidden = true;
      var name = player.getName() || G.t("guest");
      var photo = player.getPhoto("small");
      if (userName) userName.textContent = name;
      if (photo && userAvatar) { userAvatar.src = photo; userAvatar.hidden = false; }
      if (userBar) userBar.hidden = false;
    }

    if (loginBtn) loginBtn.addEventListener("click", function () {
      ysdk.auth.openAuthDialog().then(function () {
        ysdk.getPlayer({ scopes: false }).then(function (player) {
          G.player = player;
          showPlayerInfo(player);
          loadCloudData(player);
        });
      }).catch(function () {});
    });
  }

  /* ---- cloud saves ---- */
  function loadCloudData(player) {
    if (!player || !player.getData) return;
    player.getData(["settings"]).then(function (data) {
      if (!data || !data.settings) return;
      var s = data.settings;
      if (s.skin) { G.activeSkin = s.skin; G.applySkin(s.skin); }
      if (Array.isArray(s.ownedSkins)) G.ownedSkins = s.ownedSkins;
      if (s.showAds === false) G.showAds = false;
      if (s.stats) {
        G.stats.wins = s.stats.wins || 0;
        G.stats.losses = s.stats.losses || 0;
        G.stats.draws = s.stats.draws || 0;
      }
      if (typeof s.coins === "number" && !Number.isNaN(s.coins)) G.coins = Math.max(0, Math.floor(s.coins));
      if (G.updateStatsUI) G.updateStatsUI();
      if (G.updateCoinsUI) G.updateCoinsUI();
      if (catalogCache) G.renderShopItems(catalogCache);
    }).catch(function () {});
  }

  G.saveCloud = function () {
    if (!G.player || !G.player.setData) return;
    G.player.setData({
      settings: {
        skin: G.activeSkin,
        ownedSkins: G.ownedSkins,
        showAds: G.showAds,
        stats: G.stats,
        coins: G.coins
      }
    }).catch(function () {});
  };

  /* ---- leaderboard ---- */
  var lbInstance = null;
  var LEADERBOARD_NAME = "wins";

  function initLeaderboard(ysdk) {
    ysdk.getLeaderboards().then(function (lb) {
      lbInstance = lb;
      if (G.openLeaderboard) G.openLeaderboard();
    }).catch(function () {
      if (G.openLeaderboard) G.openLeaderboard();
    });
  }

  G.submitScore = function () {
    if (!lbInstance) return;
    lbInstance.setLeaderboardScore(LEADERBOARD_NAME, G.stats.wins).catch(function () {});
  };

  G.loadLeaderboard = function () {
    if (!lbInstance) { G.showLeaderboardError(); return; }
    lbInstance.getLeaderboardEntries(LEADERBOARD_NAME, { quantityTop: 10, includeUser: true })
      .then(function (res) {
        var entries = (res.entries || []).map(function (e) {
          var p = e.player || {};
          return {
            rank: e.rank,
            name: p.publicName || G.t("guest"),
            avatar: p.scopePermissions && p.scopePermissions.avatar !== "forbid"
              ? (p.getAvatarSrc ? p.getAvatarSrc("small") : "")
              : "",
            score: e.score,
            isCurrentPlayer: Boolean(e.player && G.player && e.player.uniqueID === G.player.getUniqueID())
          };
        });
        G.renderLeaderboard(entries);
      })
      .catch(function () { G.showLeaderboardError(); });
  };

  /* ---- visibility / pause ---- */
  document.addEventListener("visibilitychange", function () {
    if (!G.ysdk) return;
    if (document.hidden) {
      try { G.ysdk.features.GameplayAPI.stop(); } catch (e) {}
    } else {
      try { G.ysdk.features.GameplayAPI.start(); } catch (e) {}
    }
  });

  /* ---- SDK init ---- */
  G.initYandexSDK = function () {
    if (typeof YaGames === "undefined") {
      G.applyI18n(); G.initUI();
      if (G.openLeaderboard) G.openLeaderboard();
      return;
    }
    YaGames.init().then(function (ysdk) {
      G.ysdk = ysdk;
      G.lang = detectLang(ysdk);
      G.applyI18n();

      try { ysdk.features.LoadingAPI.ready(); } catch (e) {}
      try { ysdk.features.GameplayAPI.start(); } catch (e) {}

      initAuth(ysdk);
      initPayments(ysdk);
      initLeaderboard(ysdk);

      G.initUI();
    }).catch(function () {
      G.applyI18n(); G.initUI();
      if (G.openLeaderboard) G.openLeaderboard();
    });
  };
})(window.Game);
